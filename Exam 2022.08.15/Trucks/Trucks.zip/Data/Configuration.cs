﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-T8N6Q4C\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}
