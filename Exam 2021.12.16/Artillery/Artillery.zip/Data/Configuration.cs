﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-T8N6Q4C\SQLEXPRESS;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
