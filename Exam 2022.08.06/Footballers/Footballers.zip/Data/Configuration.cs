﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-T8N6Q4C\SQLEXPRESS;Database=FootballersExam;Trusted_Connection=True";
    }
}
